package br.edu.ifsul.controle;

import br.edu.ifsul.dao.JogadorDAO;
import br.edu.ifsul.dao.TimeDAO;
import br.edu.ifsul.modelo.Jogador;
import br.edu.ifsul.modelo.Time;
import br.edu.ifsul.util.Util;
import java.io.Serializable;
import javax.ejb.EJB;
import javax.enterprise.context.SessionScoped;
import javax.inject.Named;

@SessionScoped
@Named(value = "controleTime")
public class ControleTime implements Serializable {

    @EJB
    private TimeDAO dao;
    private Time objeto;

    private JogadorDAO jogadorDAO;
    private Jogador jogador;
    private boolean novoJogador;

    public ControleTime() {
        jogadorDAO = new JogadorDAO();
    }

    public String listar() {
        return "/privado/time/listar?faces-redirect=true";
    }

    public void novo() {
        objeto = new Time();
    }

    public TimeDAO getDao() {
        return dao;
    }

    public void alterar(Object id) {
        try {
            setObjeto(dao.getObjectById(id));
        } catch (Exception e) {
            Util.mensagemErro("Erro ao recuperar objeto: "
                    + Util.getMensagemErro(e));
        }
    }

    public void excluir(Object id) {
        try {
            setObjeto(dao.getObjectById(id));
            dao.remover(getObjeto());
            Util.mensagemInformacao("Objeto removido com sucesso!");
        } catch (Exception e) {
            Util.mensagemErro("Erro ao remover objeto: "
                    + Util.getMensagemErro(e));
        }
    }

    public void salvar() {
        try {
            if (getObjeto().getId() == null) {
                dao.persist(getObjeto());
            } else {
                dao.merge(getObjeto());
            }
            Util.mensagemInformacao("Objeto persistido com sucesso!");
        } catch (Exception e) {
            Util.mensagemErro("Erro ao persistir objeto: "
                    + Util.getMensagemErro(e));
        }
    }

    public Time getObjeto() {
        return objeto;
    }

    public void setObjeto(Time objeto) {
        this.objeto = objeto;
    }

    public void novoJogador() {
        setJogador(new Jogador());
        novoJogador = true;
        System.out.println("Jogador: " + getJogador());
    }

    public void alterarJogador(int index) {
        setJogador(objeto.getJogadores().get(index));
        novoJogador = false;
    }

    public void salvarJogador() {
        if (novoJogador) {
            objeto.adicionarJogador(getJogador());
        }
        Util.mensagemInformacao("Jogador adicionado com sucesso");
    }

    public void removerJogador(int index) {
        objeto.removerJogador(index);
        Util.mensagemInformacao("Jogador removido com sucesso");
    }

    public JogadorDAO getJogadorDAO() {
        return jogadorDAO;
    }

    public void setJogadorDAO(JogadorDAO jogadorDAO) {
        this.jogadorDAO = jogadorDAO;
    }

    public Jogador getJogador() {
        return jogador;
    }

    public void setJogador(Jogador jogador) {
        this.jogador = jogador;
    }

    public boolean isNovoJogador() {
        return novoJogador;
    }

    public void setNovoJogador(boolean novoJogador) {
        this.novoJogador = novoJogador;
    }

}
