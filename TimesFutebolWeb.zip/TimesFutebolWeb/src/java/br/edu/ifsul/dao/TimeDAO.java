package br.edu.ifsul.dao;

import br.edu.ifsul.converter.ConverterOrdem;
import br.edu.ifsul.modelo.Time;
import java.io.Serializable;
import javax.ejb.Stateful;

@Stateful
public class TimeDAO extends DAOGenerico<Time> implements Serializable {

    public TimeDAO() {
        super(Time.class);
        Time time = new Time();

        listaOrdem.add(new Ordem("id", "ID", "="));
        listaOrdem.add(new Ordem("nome", "Nome", "like"));
        ordemAtual = listaOrdem.get(1);
        converterOrdem = new ConverterOrdem(listaOrdem);
    }

    @Override
    public Time getObjectById(Object id) throws Exception {
        Time time = (Time) em.find(Time.class, id);
        time.getJogadores().size();
        return time;
    }
}
